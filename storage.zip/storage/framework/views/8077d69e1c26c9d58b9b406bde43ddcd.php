<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <section>


        <div class="content-page-header">
            <h5 class="setting-menu">Profile</h5>
        </div>
        <form id="profileForm" action="<?php echo e(route('profile.upload_pic')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="profile-picture">
                <div class="upload-profile me-2">
                    <div class="profile-img">
                        <img id="blah" class="avatar"
                            src="<?php echo e(asset(auth()->user()->profile_pic ?? 'assets/img/profiles/avatar-10.jpg')); ?>"
                            alt="profile-img">
                    </div>
                </div>
                <div class="img-upload">
                    <label class="btn btn-primary">
                        Upload new picture <input type="file" name="profile_pic" id="profile_pic" hidden>
                    </label>
                    <p class="mt-1">Logo Should be minimum 152 * 152 Supported File format JPG, PNG, SVG</p>
                </div>
            </div>
        </form>
        <form method="post" action="<?php echo e(route('profile.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="row">

                <div class="col-lg-12">
                    <div class="form-title">
                        <h5>General Information</h5>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="input-block mb-3">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control"
                            placeholder="Enter First Name">
                        <span class="error text-danger"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>

                </div>
                <div class="col-lg-6 col-12">
                    <div class="input-block mb-3">
                        <label>Email</label>
                        <input type="text" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control"
                            readonly placeholder="Enter Email Address">
                        <span class="error text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="input-block mb-3">
                        <label>Phone No</label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" class="form-control"
                            placeholder="Enter Mobile Number">
                        <span class="error text-danger"><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="input-block mb-3">
                        <label>Address</label>
                        <input type="text" name="address" value="<?php echo e(old('address', $user->address)); ?>"
                            class="form-control" placeholder="Enter your Address">
                        <span class="error text-danger"><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

                    </div>
                </div>

                
                
                
                <div class="col-lg-12">
                    <div class="btn-path text-end">
                        
                        <button class="btn btn-primary" type="submit">Update</button>
                    </div>
                </div>

            </div>
        </form>

    </section>
    <script>
        document.getElementById('profile_pic').addEventListener('change', function(event) {
            let file = event.target.files[0];
            
            if (file) {
                let reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('blah').src = e.target.result; // Image preview
                };
                reader.readAsDataURL(file);
    
                // Form automatically submit kare
                document.getElementById('profileForm').submit();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/profile/edit.blade.php ENDPATH**/ ?>