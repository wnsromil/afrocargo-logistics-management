<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Parcel Management')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('cardTitle', null, []); ?> 
        All Parcels
        
        

     <?php $__env->endSlot(); ?>

    <div>
        <div class="card-table">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-stripped table-hover datatable">
                        <thead class="thead-light">
                            <tr>
                                
                                <th>Sn no.</th>
                                <th>Tracking ID</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Amount</th>
                                <th>Payment Mode</th>
                                
                                <th>Pickup Date</th>
                                <th>Delivery Date</th>
                                <th>Status</th>
                                <th>Status update</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $parcels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $parcel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    
                                    <td><?php echo e(++$index); ?></td>
                                    <td>
                                        <?php echo e(ucfirst($parcel->tracking_number ?? '-')); ?>

                                    </td>
                                    <td>
                                        <div>
                                            <p>
                                                <i class="fe fe-user"></i><?php echo e(ucfirst($parcel->customer->name ?? '-')); ?>

                                            </p>
                                            <p>
                                                <i class="fe fe-phone"></i><?php echo e($parcel->customer->phone ?? '-'); ?>

                                            </p>
                                            <p>
                                                <i class="fe fe-map-pin"></i><?php echo e($parcel->customer->address ?? '-'); ?>

                                            </p>
                                        </div>
                                    </td>
                                    <td>
                                        <div>
                                            <p>
                                                <i class="fe fe-user"></i><?php echo e(ucfirst($parcel->destination_user_name ?? '-')); ?>

                                            </p>
                                            <p>
                                                <i class="fe fe-phone"></i><?php echo e($parcel->destination_user_phone ?? '-'); ?>

                                            </p>
                                            <p>
                                                <i class="fe fe-map-pin"></i><?php echo e($parcel->destination_address ?? '-'); ?>

                                            </p>
                                        </div>
                                    </td>
                                    
                                    
                                    <td>
                                        <div>
                                            <p>
                                                <span class="fw-bold">Partial:</span>
                                                <span>$<?php echo e($parcel->partial_payment ?? '-'); ?></span>
                                            </p>
                                            <p>
                                                <span class="fw-bold">Due:</span>
                                                <span>$<?php echo e($parcel->remaining_payment ?? '-'); ?></span>
                                            </p>
                                            <p>
                                                <span class="fw-bold">Total:</span>
                                                <span>$<?php echo e($parcel->total_amount ?? '-'); ?></span>
                                            </p>
                                        </div>
                                        
                                    </td>
                                    <td><span><?php echo e(ucfirst($parcel->payment_type ?? '-')); ?></span>
                                    </td>
                                    <td>
                                        <span><?php echo e($parcel->pickup_date ? \Carbon\Carbon::parse($parcel->pickup_date)->format('d/m/Y') : '-'); ?></span>
                                    </td>
                                    <td>
                                        <span><?php echo e($parcel->delivery_date ? \Carbon\Carbon::parse($parcel->delivery_date)->format('d/m/Y') : '-'); ?></span>
                                    </td>
                                    <td><span
                                            class="badge-<?php echo e(activeStatusKey($parcel->status)); ?>"><?php echo e($parcel->status ?? '-'); ?></span>
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="dropdown">
                                            <span class="dropdown-icon-status" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                                <i class="fas fa-chevron-down"></i>
                                            </span>
                                            <ul class="dropdown-menu">
                                                <?php if($parcel->status == 'Pending'): ?>
                                                    <li>
                                                        <span class="dropdown-item"
                                                            onclick="handlePickupAssign(<?php echo e($parcel->id); ?>, <?php echo e(json_encode($drivers)); ?>)">
                                                            <i class="fas fa-truck me-2"></i>Pickup Assign
                                                        </span>
                                                    </li>
                                                <?php elseif($parcel->status == 'Pickup Assign'): ?>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handlePickupCancel(<?php echo e($parcel->id); ?>)">
                                                            <i class="fas fa-times-circle me-2"></i>Pickup Cancel
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handlePickupReschedule(<?php echo e($parcel->id); ?>, <?php echo e(json_encode($drivers)); ?>)">
                                                            <i class="fas fa-calendar-alt me-2"></i>Pickup Re-Schedule
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handleReceivedByPickupMan(<?php echo e($parcel->id); ?>)">
                                                            <i class="fas fa-box-open me-2"></i>Received By Pickup Man
                                                        </span>
                                                    </li>
                                                <?php elseif($parcel->status == 'Pickup Re-Schedule'): ?>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handlePickupReschedule(<?php echo e($parcel->id); ?>, <?php echo e(json_encode($drivers)); ?>)">
                                                            <i class="fas fa-calendar-alt me-2"></i>Pickup Re-Schedule
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handleReceivedWarehouse(<?php echo e($parcel->id); ?>, <?php echo e(json_encode($warehouses)); ?>)">
                                                            <i class="fas fa-warehouse me-2"></i>Received Warehouse
                                                        </span>
                                                    </li>
                                                <?php elseif($parcel->status == 'Received Warehouse'): ?>
                                                    <li>
                                                        <span class="dropdown-item" onclick="handleTransferToHub(<?php echo e($parcel->id); ?>, <?php echo e(json_encode($drivers)); ?>)">
                                                            <i class="fas fa-calendar-alt me-2"></i>Transfer To Hub
                                                        </span>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </td>

                                    <td class="align-items-center">
                                        <span class="dropdown-icon-status">
                                            <a href="<?php echo e(route('admin.OrderShipment.show', $parcel->id)); ?>">
                                                <i class="far fa-eye my-1 text-white"></i>
                                                
                                            </a>
                                        </span>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="px-4 py-4 text-center text-gray-500">No parcels found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="bottom-user-page mt-3">
                    <?php echo $parcels->links('pagination::bootstrap-5'); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    function handlePickupAssign(ParcelId, drivers) {
        let options = `<option value="">Select Pickup Man</option>`;
        drivers.forEach(driver => {
            options += `<option value="${driver.id}">${driver.name}</option>`;
        });

        const Input_Fields = [
            {
                id: "pickup-man",
                label: "Pickup Man",
                type: "select",
                options: options,
                required: true
            },
            {
                id: "note",
                label: "Note",
                type: "textarea",
                required: false
            }
        ];

        let selectedUsers = [];
        $(".selectCheckbox:checked").each(function () {
            selectedUsers.push($(this).val());
        });

        if(ParcelId=="selectArr"){
            ParcelId =selectedUsers;
        }

        const status = "Pickup Assign";
        DynmicModel(ParcelId, status, Input_Fields);
    }

    function handlePickupReschedule(ParcelId, drivers) {
        let options = `<option value="">Select Pickup Man</option>`;
        drivers.forEach(driver => {
            options += `<option value="${driver.id}">${driver.name}</option>`;
        });

        const Input_Fields = [
            {
                id: "pickup-man",
                label: "Pickup Man",
                type: "select",
                options: options,
                required: true
            },
            {
                id: "pickup_date",
                label: "Pickup Date",
                type: "date",
                required: true
            },
            {
                id: "note",
                label: "Note",
                type: "textarea",
                required: false
            }
            
        ];

        const status = "Pickup Re-Schedule";
        DynmicModel(ParcelId, status, Input_Fields);
    }

    function handlePickupCancel(ParcelId) {
        const status = "Cancelled";
        DynmicModel(ParcelId, status, []);
        console.log("❌ Pickup Cancel Clicked");
    }

    function handleReceivedByPickupMan(ParcelId=false) {
        const status = "Received By Pickup Man";
        DynmicModel(ParcelId, status, []);
    }

    function handleReceivedWarehouse(ParcelId, warehouses) {
        let options = `<option value="">Select Warehouse</option>`;
        warehouses.forEach(warehouse => {
            options += `<option value="${warehouse.id}">${warehouse.warehouse_name}</option>`;
        });

        const Input_Fields = [
            {
                id: "warehouse_id",
                label: "Warehouse",
                type: "select",
                options: options,
                required: true
            },
            {
                id: "note",
                label: "Note",
                type: "textarea",
                required: false
            }
        ];

        const status = "Received Warehouse";
        DynmicModel(ParcelId, status, Input_Fields );
        console.log("🏢 Received Warehouse Clicked");
    }

    async function DynmicModel(ParcelId, status, Input_Fields) {
        var _token = '<?php echo e(csrf_token()); ?>';

        // Generate Dynamic HTML Inputs
        let formHtml = "";
        Input_Fields.forEach(field => {
            if (field.type === "select") {
                formHtml += `
                <label for="${field.id}" style="display:block; text-align:left; font-weight:bold; margin-top: 10px;">${field.label}</label>
                <select id="${field.id}" class="swal2-input">${field.options}</select>`;
            } else if (field.type === "textarea") {
                formHtml += `
                <label for="${field.id}" style="display:block; text-align:left; font-weight:bold; margin-top: 10px;">${field.label}</label>
                <textarea id="${field.id}" class="swal2-input textarea-swal2-input" rows="4" cols="50"></textarea>`;
            } else if (field.type === "date") {
                formHtml += `
                <label for="${field.id}" style="display:block; text-align:left; font-weight:bold; margin-top: 10px;">${field.label}</label>
                <input type="date" id="${field.id}" class="swal2-input">`;
            }
        });

        // Show SweetAlert
        const { value: formValues } = await Swal.fire({
            title: "Update Status",
            html: formHtml,
            showCancelButton: true,
            confirmButtonText: "Change",
            showCloseButton: true,
            preConfirm: () => {
                let formData = { ParcelId: ParcelId, status: status, _token: _token };
                let isValid = true;

                // Validate and collect data
                Input_Fields.forEach(field => {
                    let inputValue = document.getElementById(field.id)?.value.trim() || "";
                    if (field.required && !inputValue) {
                        Swal.showValidationMessage(`Please fill ${field.label}!`);
                        isValid = false;
                    }
                    formData[field.id] = inputValue; // Add to data object
                });

                return isValid ? formData : false;
            }
        });

        if (formValues) {
            // Send AJAX Request
            $.ajax({
                url: "<?php echo e(route('parcel.status_update')); ?>",
                type: "POST",
                data: formValues, // Dynamic data object
                success: function (response) {
                    if (response.status === true) {
                    Swal.fire({
                    title: "Good job!",
                    text: "Status change successfully!",
                    icon: "success"
                   }).then(() => {
                    location.reload(); // Page reload after OK click
                   });
                    } else {
                        Swal.fire({
                            title: "Oops...",
                            text: "Something went to wrong!",
                            icon: "error"
                        });
                    }
                },
                error: function (xhr) {
                    Swal.fire('Error!', 'An error occurred while processing your request.', 'error');
                    console.log(xhr.responseJSON);
                }
            });
        }
    }

</script><?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/admin/OrderShipment/index.blade.php ENDPATH**/ ?>