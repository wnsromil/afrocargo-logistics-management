<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Inventory Management')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('cardTitle', null, []); ?> 
        All Inventory History

        
     <?php $__env->endSlot(); ?>

    <div>

        <div class="card-table">
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-stripped table-hover datatable">
                        <thead class="thead-light">
                            <tr>
                                <th>Sn no.</th>
                                <th>Created By User</th>
                                <th>Inventory Name</th>
                                <th>Warehouse Name</th>
                                <th>Low stock Warning</th>
                                <th>In Stock Quantity</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e(++$index); ?>

                                </td>

                                <td><?php echo e(ucfirst($inventory->user->name ?? '') .' / ('. ucfirst($inventory->user->role.')' ?? '')); ?></td>
                                <td><?php echo e(ucfirst($inventory->category->name ?? '')); ?></td>
                                <td><?php echo e(ucfirst($inventory->warehouse->warehouse_name ?? '')); ?></td>
                                <td><span><?php echo e($inventory->low_stock_warning ?? '-'); ?></span></td>
                                <td><span><?php echo e($inventory->in_stock_quantity ?? '-'); ?></span></td>
                                <td><span class="badge <?php echo e($inventory->status!='Updated' ? 'bg-success-light':'bg-danger-light'); ?>"><?php echo e($inventory->status ?? '-'); ?></span>
                                </td>
                                

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="11" class="px-4 py-4 text-center text-gray-500">No users found.</td>
                            </tr>
                            <?php endif; ?>

                        </tbody>

                    </table>
                    
                    <div class="bottom-user-page mt-3">
                        <?php echo $inventories->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/admin/inventories/show.blade.php ENDPATH**/ ?>