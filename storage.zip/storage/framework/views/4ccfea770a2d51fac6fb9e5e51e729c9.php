


 <ul class="sidebar-vertical">
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $hasSubmenu = $menu->submenu->count() > 0;
        ?>

        <?php if($hasSubmenu): ?>
            <li class="submenu <?php echo e(!empty($menu->active) ? isActive($menu->active,'subdrop') : ''); ?>">
                <a href="javascript:void(0)">
                    <?php if($menu->icon): ?>
                        <img src="<?php echo e(asset($menu->icon)); ?>" alt="<?php echo e($menu->title); ?>">
                    <?php endif; ?>
                    <span><?php echo e($menu->title); ?></span>
                </a>
                <ul style="display: <?php echo e(!empty($menu->active) ? isActive($menu->active,'block','none'):''); ?>">
                    <?php $__currentLoopData = $menu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e(!empty($submenu->active) ? isActive($submenu->active) : ''); ?>">
                            <a href="<?php echo e($submenu->route && !in_array($submenu->route,["#","''"]) ? route($submenu->route) : 'javascript:void(0)'); ?>">
                                <?php if($submenu->icon): ?>
                                    <img src="<?php echo e(asset($submenu->icon)); ?>" alt="<?php echo e($submenu->title); ?>">
                                <?php endif; ?>
                                <span><?php echo e($submenu->title); ?></span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
            <li class="<?php echo e(!empty($menu->active) ? isActive($menu->active): ''); ?>">
                <a href="<?php echo e($menu->route && !in_array($menu->route,["#","''"]) ? route($menu->route) : 'javascript:void(0)'); ?>">
                    <?php if($menu->icon): ?>
                        <img src="<?php echo e(asset($menu->icon)); ?>" alt="<?php echo e($menu->title); ?>">
                    <?php endif; ?>
                    <span><?php echo e($menu->title); ?></span>
                </a>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/components/sidebar.blade.php ENDPATH**/ ?>