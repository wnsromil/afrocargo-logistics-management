<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Parcel Management')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('cardTitle', null, []); ?> 
        All Parcel History

        
     <?php $__env->endSlot(); ?>

    <div>

        <div class="card-table">
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-stripped table-hover datatable">
                        <thead class="thead-light">
                            <tr>
                                <th>Sn no.</th>
                                <th>Tracking Number</th>
                                <th>Created By</th>
                                <th>Parcel Name</th>
                                <th>Warehouse Name</th>
                                <th>Customer</th>
                                <th>Weight (kg)</th>
                                <th>Total Amount ($)</th>
                                <th>Payment Type</th>
                                <th>Parcel Status</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ParcelHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ParcelHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e(++$index); ?>

                                </td>
                                <td><span><?php echo e($ParcelHistory->description->tracking_number ?? '-'); ?></span></td>
                                <td><?php echo e(ucfirst($ParcelHistory->CreatedByUser->name ?? '') .' / ('. ucfirst($ParcelHistory->CreatedByUser->role ?? '').')'); ?></td>
                                <td><?php echo e($parcelTpyes->whereIn('id',$ParcelHistory->description->parcel_car_ids)->pluck('name')->implode(', ')); ?></td>
                                <td><?php echo e(ucfirst($ParcelHistory->warehouse->warehouse_name ?? '')); ?></td>
                                <td><?php echo e(ucfirst($ParcelHistory->customer->name ?? '') .' / ('. ucfirst($ParcelHistory->customer->role ?? '').')'); ?></td>
                                <td><span><?php echo e($ParcelHistory->description->weight ?? '-'); ?></span></td>
                                <td><span><?php echo e($ParcelHistory->description->total_amount ?? '-'); ?></span></td>
                                <td><span><?php echo e($ParcelHistory->description->payment_type ?? '-'); ?></span></td>
                                <td><span class="badge-<?php echo e(activeStatusKey($ParcelHistory->parcel_status)); ?>"><?php echo e($ParcelHistory->parcel_status ?? '-'); ?></span></td>
                                <td><span class="badge-<?php echo e(activeStatusKey($ParcelHistory->status)); ?>"><?php echo e($ParcelHistory->status ?? '-'); ?></span></td>
                            <td><span><?php echo e($ParcelHistory->created_at->format('d/m/y') ?? '-'); ?></span></td>
                                

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="11" class="px-4 py-4 text-center text-gray-500">No data found.</td>
                            </tr>
                            <?php endif; ?>

                        </tbody>

                    </table>
                    
                    <div class="bottom-user-page mt-3">
                        <?php echo $ParcelHistories->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/admin/OrderShipment/show.blade.php ENDPATH**/ ?>