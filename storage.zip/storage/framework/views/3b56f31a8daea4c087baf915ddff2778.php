<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('style'); ?>
    <style>
        /*----------- BUTTON ----------*/
        .btn-holder {
            width: 400px;
            height: 300px;
            margin: 50px auto 0;
        }

        .btn-lg.btn-toggle {
            padding: 0;
            margin: 0 5rem;
            position: relative;
            height: 2.5rem;
            width: 6rem;
            border-radius: 3rem;
            color: #6b7381;
            background: #bdc1c8;
            margin-bottom: 30px;
        }

        .btn-toggle.btn-lg>.switch {
            position: absolute;
            top: 0.2rem;
            left: 0.1rem;
            width: 2rem;
            height: 2rem;
            border-radius: 1.875rem;
            background: #fff;
            transition: left .25s;
        }

        .btn-toggle.active {
            background-color: #ff8800;
        }

        .btn-toggle.btn-lg.active>.switch {
            left: 3.75rem;
            transition: left .25s;
        }
        .btn-lg.btn-toggle::before {
            content: "Inactive";
            right: -5rem;
            opacity: 0.5;
            line-height: 2.5rem;
            width: 5rem;
            text-align: center;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 2px;
            position: absolute;
            bottom: 0;
            transition: opacity .25s;
        }
        .btn-lg.btn-toggle:after {
            content: "Active";
            right: -5rem;
            opacity: 0.5;
            line-height: 2.5rem;
            width: 5rem;
            text-align: center;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 2px;
            position: absolute;
            bottom: 0;
            transition: opacity .25s;
        }

        .btn-lg.btn-toggle.active:after {
            opacity: 1;
        }

        /*------------ CHECKBOX -------------*/
        .toggle-switch {
            margin: 0 auto;
            width: 241px;
            margin-top: 20px;
            position: relative;
        }

        .toggle-switch label {
            padding: 0;
        }

        input#cb-switch {
            display: none;
        }

        .toggle-switch label input+span {
            position: relative;
            display: inline-block;
            margin-right: 10px;
            width: 6rem;
            height: 2.5rem;
            background: #bdc1c8;
            border: 1px solid #eee;
            border-radius: 50px;
            transition: all 0.3s ease-in-out;
            box-shadow: inset 0 0 5px #828282;
        }

        .toggle-switch label input+span small {
            position: absolute;
            display: block;
            width: 2rem;
            height: 2rem;
            border-radius: 1.875rem;
            background: #fff;
            transition: all 0.3s ease-in-out;
            top: 0.2rem;
            left: 0.2rem;
        }

        .toggle-switch label input:checked+span {
            background-color: #ff8800;
        }

        .toggle-switch label input:checked+span small {
            left: 3.7rem;
            transition: left .25s;
        }

        .toggle-switch span:after {
            content: "Active";
            line-height: 2.5rem;
            width: 5rem;
            text-align: center;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 2px;
            position: absolute;
            bottom: 0;
            transition: opacity .25s;
            left: 6rem;
            opacity: 0.5;
            color: #6b7381;
        }

        .toggle-switch label input:checked+span:after {
            opacity: 1;
        }
    </style>

    <?php $__env->stopSection(); ?>
     <?php $__env->slot('header', null, []); ?> 
        Warehouse
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('cardTitle', null, []); ?> 
        Edit Warehouse
     <?php $__env->endSlot(); ?>

    <form action="<?php echo e(route('admin.warehouses.update',$warehouse->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group-customer customer-additional-form">
            <div class="row">
                <!-- Warehouse Name -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="warehouse_name">Warehouse Name <i class="text-danger">*</i></label>
                        <input type="text" name="warehouse_name" class="form-control" placeholder="Enter Warehouse Name"
                            value="<?php echo e($warehouse->warehouse_name ?? old('warehouse_name')); ?>">
                        <?php $__errorArgs = ['warehouse_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Warehouse Code -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="warehouse_code">Warehouse Code <i class="text-danger">*</i></label>
                        <input type="text" name="warehouse_code" class="form-control" placeholder="Enter Warehouse Code"
                            value="<?php echo e($warehouse->warehouse_code ?? old('warehouse_code')); ?>">
                        <?php $__errorArgs = ['warehouse_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Address -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="address">Address <i class="text-danger">*</i></label>
                        <input type="text" name="address" class="form-control" placeholder="Enter Address"
                            value="<?php echo e($warehouse->address ?? old('address')); ?>">
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Country -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="country_id">Country <i class="text-danger">*</i></label>

                        <select name="country_id" id="country" class="form-control">
                            <option value="">Select Country</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($warehouse->country_id == $country->id ? 'selected':''); ?> value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- State -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="state_id">State <i class="text-danger">*</i></label>
                        <select name="state_id" id="state" class="form-control">
                            <option value="">Select State</option>
                        </select>
                        <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- City -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="city_id">City <i class="text-danger">*</i></label>
                        <select name="city_id" id="city" class="form-control">
                            <option value="">Select City</option>
                        </select>
                        <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Zip Code -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="zip_code">Zip Code <i class="text-danger">*</i></label>
                        <input type="text" name="zip_code" class="form-control" placeholder="Enter Zip Code"
                        value="<?php echo e($warehouse->zip_code ?? old('zip_code')); ?>">
                        <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Contact Number -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="phone">Contact Number <i class="text-danger">*</i></label>
                        <input type="text" name="phone" class="form-control" placeholder="Enter Contact Number"
                        value="<?php echo e($warehouse->phone ?? old('phone')); ?>">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Status -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="input-block mb-3">
                        <label for="status">Status <i class="text-danger">*</i></label>
                        <div class="toggle-switch">
                            <label for="cb-switch">
                                <input type="checkbox" id="cb-switch" name="status" <?php echo e($warehouse->status =='Active' ? 'checked':''); ?> value="Active">
                                <span>
                                    <small></small>
                                </span>
                            </label>
                        </div>


                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="add-customer-btns text-end">
            <a href="<?php echo e(route('admin.warehouses.index')); ?>" class="btn customer-btn-cancel">Cancel</a>
            <button type="submit" class="btn customer-btn-save">Submit</button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/admin/warehouse/edit.blade.php ENDPATH**/ ?>