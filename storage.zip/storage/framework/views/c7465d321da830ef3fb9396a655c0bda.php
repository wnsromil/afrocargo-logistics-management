<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Warehouse Management')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('cardTitle', null, []); ?> 
        Create New User

        <div class="d-flex align-items-center justify-content-end mb-1">
            <div class="usersearch d-flex">
                <div class="mt-2">
                    <a href="<?php echo e(route('admin.vehicle.create')); ?>" class="btn btn-primary">
                        <i
                            class="fa fa-plus-circle me-2"></i>Add Warehouse
                    </a>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div>

        <div class="card-table">
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-stripped table-hover datatable">
                        <thead class="thead-light">
                            <tr>
                                <th>Sn no.</th>
                                <th>Warehouse Name</th>
                                <th>Warehouse Code</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Country</th>
                                <th>Zip Code</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e(++$index); ?>

                                </td>
    
                                <td><?php echo e(ucfirst($warehouse->warehouse_name ?? '')); ?></td>
                                <td><span><?php echo e($warehouse->warehouse_code ?? '-'); ?></span></td>
                                <td><?php echo e($warehouse->address ?? '-'); ?></td>
                                <td><?php echo e($warehouse->city->name ?? '-'); ?></td>
                                <td><?php echo e($warehouse->state->name ?? '-'); ?></td>
                                <td><?php echo e($warehouse->country->name ?? '-'); ?></td>
                                <td><?php echo e($warehouse->zip_code ?? '-'); ?></td>
                                <td><?php echo e($warehouse->phone ?? '-'); ?></td>
                                <td><span class="badge <?php echo e($warehouse->status=='Active' ? 'bg-success-light':'bg-danger-light'); ?>"><?php echo e($warehouse->status ?? '-'); ?></span>
                                </td>
                                <td class="d-flex align-items-center">
                                    
                                    <div class="dropdown dropdown-action">
                                        <a href="#" class=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <ul>
                                                <li>
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.vehicle.edit',$warehouse->id)); ?>"><i class="far fa-edit me-2"></i>Edit</a>
                                                </li>
                                                <li>
                                                    <!-- Delete form -->
                                                    <form action="<?php echo e(route('admin.vehicle.destroy', $warehouse->id)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item"><i class="far fa-trash-alt me-2"></i>Delete</button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="customer-details.html"><i class="far fa-eye me-2"></i>View</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="active-customers.html"><i class="fa-solid fa-power-off me-2"></i>Activate</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="deactive-customers.html"><i class="far fa-bell-slash me-2"></i>Deactivate</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="11" class="px-4 py-4 text-center text-gray-500">No data found.</td>
                            </tr>
                            <?php endif; ?>

                        </tbody>

                    </table>
                    
                    <div class="bottom-user-page mt-3">
                        <?php echo $vehicles->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/afrocargo-logistics-management/resources/views/admin/vehicle/index.blade.php ENDPATH**/ ?>